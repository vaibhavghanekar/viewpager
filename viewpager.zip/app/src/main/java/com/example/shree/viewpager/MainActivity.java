package com.example.shree.viewpager;

import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.viewpagerindicator.CirclePageIndicator;
import com.viewpagerindicator.TitlePageIndicator;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    MyPageAdapter pageAdapter;
    String url = "http://www.androidbegin.com/tutorial/jsonparsetutorial.txt";
    Example example;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getRequest();
    }

    private void getRequest() {
        RequestQueue queue = Volley.newRequestQueue(this);
        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Toast.makeText(MainActivity.this, "1", Toast.LENGTH_SHORT).show();
                Log.d("response=>", response.toString());

                String json = String.valueOf(response);
                Gson gson = new Gson();
                example = gson.fromJson(json, Example.class);

                List<Fragment> fragments = getFragments();
                pageAdapter = new MyPageAdapter(getSupportFragmentManager(), fragments);

                ViewPager pager = (ViewPager) findViewById(R.id.viewpager);
                pager.setAdapter(pageAdapter);

                CirclePageIndicator titleIndicator = (CirclePageIndicator)findViewById(R.id.titles);
                titleIndicator.setFillColor(getResources().getColor(R.color.colorAccent));
                titleIndicator.setPageColor(getResources().getColor(R.color.colorPrimary));
                titleIndicator.setViewPager(pager);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "2", Toast.LENGTH_SHORT).show();
                Log.d("response=>", String.valueOf(error));
            }
        });
        queue.add(jsObjRequest);
    }

    private List<Fragment> getFragments() {

        List<Fragment> fragments = new ArrayList<>();

        for (int i = 0; i < example.getWorldpopulation().size(); i++) {
            fragments.add(BlankFragment.newInstance("Fragment" + example.getWorldpopulation().get(i).getRank(), example.getWorldpopulation().get(i).getCountry()));
        }
        return fragments;
    }
}
