package com.example.shree.viewpager;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends Fragment {

    public static final String EXTRA_MESSAGE1 = "EXTRA_MESSAGE1";
    public static final String EXTRA_MESSAGE2 = "EXTRA_MESSAGE2";

    public BlankFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        String message1 = getArguments().getString(EXTRA_MESSAGE1);
        String message2 = getArguments().getString(EXTRA_MESSAGE2);

        View v = inflater.inflate(R.layout.fragment_blank, container, false);

        TextView messageTextView1 = (TextView) v.findViewById(R.id.textView1);
        TextView messageTextView2 = (TextView) v.findViewById(R.id.textView2);

        messageTextView1.setText(message1);
        messageTextView2.setText(message2);

        return v;
    }

    public static Fragment newInstance(String message1, String message2) {
        BlankFragment f = new BlankFragment();

        Bundle bdl = new Bundle(1);

        bdl.putString(EXTRA_MESSAGE1, message1);
        bdl.putString(EXTRA_MESSAGE2, message2);

        f.setArguments(bdl);

        return f;
    }
}
